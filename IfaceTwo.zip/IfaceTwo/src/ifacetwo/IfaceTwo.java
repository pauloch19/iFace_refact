package ifacetwo;
import java.util.Scanner;
/**
 *
 * @author paulc
 */
public class IfaceTwo {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Sys system = new Sys();
        Logged logged = new Logged();
        Presentation pres = new Presentation();
        System.out.println("Welcome to iFace!");
        pres.MainMenu(system, logged);
        System.out.println(system.listUsers.size());
        // TODO code application logic here
    }
    
}
