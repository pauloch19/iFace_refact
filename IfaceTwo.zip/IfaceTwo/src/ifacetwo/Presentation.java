package ifacetwo;
import java.util.Scanner;
/**
 *
 * @author paulc
 */
public class Presentation {
    Scanner input = new Scanner(System.in);
    
    public void MainMenu(Sys system, Logged logged){
     User user = new User();
     System.out.println("Escolha umas das opções abaixo: ");
     System.out.println("Login, Caso você já tenha uma conta.");
     System.out.println("Cadastrar, caso você não tenha uma conta.");
     System.out.println("Recuperar, caso você tenha perdido a senha.");
     System.out.println("Sair, caso você deseje encerrar o programa.");
     System.out.print("opção: ");
     String option = input.nextLine();
     option = option.toLowerCase();
     while(!option.equals("sair"))
     {
        if(option.equals("cadastrar"))
        {
            Register(system);
            System.out.println("Usuário registrado no sistema.");
        }
        if(option.equals("login"))
        {
            user = LogIn(system);
            if(user!=null)
            {
                System.out.println("Login realizado com sucesso!");
                logged.MainMenuLogged(user, system);
            }
            else
            {
                System.out.println("Você saiu da opção login.");
            }
        }
        System.out.println("Escolha umas das opções abaixo: ");
        System.out.println("Login, Caso você já tenha uma conta.");
        System.out.println("Cadastrar, caso você não tenha uma conta.");
        System.out.println("Recuperar, caso você tenha perdido a senha.");
        System.out.println("Sair, caso você deseje encerrar o programa.");
        System.out.print("opção: ");
        option = input.nextLine();
        option = option.toLowerCase();
     }
    
    
    }
    
    public void RecoverAccount(Sys system)
    {
        System.out.print("Login: ");
        String login = input.nextLine();
        User user = system.SearchUser(login);
        if(user!=null)
        {
            System.out.print("Digite sua frase de segurança: ");
            String security = input.nextLine();
            if(user.getSecurity().equals(security))
            {
                System.out.println("Sua senha é: "+user.getPassword());
            }
        }
        else
        {
            System.out.println("Usuário não encontrado.");
        }
    }
    
    
    public void Register(Sys system){
        
        System.out.println("Você entrou na opção de registro.");
        System.out.print("Login: ");
        String login = input.nextLine();
        System.out.print("Senha: ");
        String password = input.nextLine();
        System.out.print("Frase de segurança: ");
        String security = input.nextLine();
        while(system.SearchForEqualsLogin(login))
        {
            System.out.println("Já existe um usuário com esse login, por favor, escolha outro.");
            System.out.print("Login: ");
            login = input.nextLine();
        }
        User user = new User();
        user.setSecurity(security);
        user.setLogin(login);
        user.setPassword(password);
        system.AddUser(user);
        
    }
    
    public User LogIn(Sys system){
        boolean verification = false;
        User user = null;
        String login;
        String password;
        System.out.println("Você entrou na opção de login.");
        while(!verification)
        {
            System.out.println("Para sair da opção de login, digite sair no espaço de login ou senha.");
            System.out.print("Login: ");
            login = input.nextLine();
            System.out.print("Senha: ");
            password = input.nextLine();
            if(login.equals("sair") || password.equals("sair"))
            {
                verification=true;
            }
            else
            {
                user = system.SearchUser(login);
                if(user==null)
                {
                    System.out.println("Usuário não encontrado.");
                    System.out.println("O login pode está incorreto.");
                }
                else
                {
                    if(user.getPassword().equals(password))
                    {
                        System.out.println("Login e Password estão corretos.");
                        verification=true;
                    }
                    else
                    {
                        System.out.println("Não foi possivel fazer login, verifique sua senha.");
                    }
                }
            }
        }
        
        return user;
    }
    
    
}


