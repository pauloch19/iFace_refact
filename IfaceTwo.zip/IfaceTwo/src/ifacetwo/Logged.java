/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ifacetwo;
import java.util.Scanner;
/**
 *
 * @author paulc
 */
public class Logged {
    Scanner input = new Scanner(System.in);
    
    public void MainMenuLogged(User user, Sys system){
        int option;
        System.out.println("Você está logado com o login: "+user.getLogin());
        System.out.println("1.Criar perfil\n2.Ver Perfil\n3.Amigos\n4.Mensagens\n5.Comunidades\n6.Remover conta\n7.Sair");
        option = CheckException("Escolha uma das opções acima: ");
        input.nextLine();
        while(option!=7)
        {
            
            if(option==1)
            {
                System.out.println("Você entrou na opção criar perfil.");
                if(user.getPerfil().equals("not created"))
                {
                    CreatePerfil(user);
                }
                else
                {
                    System.out.println("O seu perfil já foi criado.");
                }
                
            }
            if(option==2)
            {
                System.out.println("Você entrou na opção ver perfil.");
                System.out.println(user.toString());
            }
            if(option==3)
            {
                System.out.println("Você entrou na opção adicionar amigo.");
                System.out.println("1.Adicionar\n2.Verificar Convites\n3.Lista de Amigos");
                option = CheckException("Escolha uma das opções acima: ");
                input.nextLine();
                if(option==1)
                {
                    AddFriend(system, user);
                }
                if(option==2)
                {
                    CheckInvites(user);
                }
                if(option==3)
                {
                    user.FriendList();
                }
            }
            if(option==4)
            {
                System.out.println("Você entrou na opção Mensagem");
                System.out.println("1.Enviar Mensagem\n2.Ver Conversa");
                option = CheckException("Escolha uma das opções acima: ");
                input.nextLine();
                if(option==1)
                {
                    SendMessages(system, user);
                }
                if(option==2)
                {
                    SeeMessage(system, user);
                }
                
            }
            if(option==5)
            {
                System.out.println("Você entrou na opção comunidades.");
                System.out.println("1.Gerenciar minhas comunidades\n2.Ver minhas comunidades\n3.Ver comunidades existentes\n4.Enviar Mensagem");
                option = CheckException("Escolha uma das opções acima: ");
                input.nextLine();
                if(option==1)
                {
                    System.out.println("1.Criar comunidade\n2.Verificar lista de solicitação de entrada\n3.Remover membro");
                    option = CheckException("Escolha uma das opções acima: ");
                    input.nextLine();
                    switch (option) {
                        case 1:
                            CreateCommunity(system, user);
                            break;
                        case 2:
                            system.SearchCommunity(user);
                            break;
                        case 3:
                            System.out.print("Nome da comunidade: ");
                            String communityName = input.nextLine();
                            system.RemoveMember(user, communityName);
                            break;
                        default:
                            break;
                    }
                }
                else if(option==2)
                {
                    System.out.println("Você entrou na opção para ver as comunidades das quais faz parte e é administrador.");
                    system.SeeMyCommunities(user);
                }
                else if(option==3)
                {
                    System.out.println("Você entrou na opção para ver as comunidades existentes no sistema.");
                    system.CommunitiesSystem(user);
                }
                else if(option==4)
                {
                    System.out.println("Você entrou na opção para enviar mensagens.");
                    System.out.print("Nome da comunidade: ");
                    String communityName = input.nextLine();
                    system.CommunityMessage(communityName, user);
                }
                
            }
            if(option==6)
            {
                System.out.println("Você entrou na opção para remover contas do sistema");
                System.out.println("Todas as informações da sua conta será removida.");
                system.Delete(user);
                system.DeleteFromCommunity(user);
                system.listUsers.remove(user.getLogin());
                System.out.println("Usuário removido com sucesso!");
                break;
            }
            System.out.println("1.Criar perfil\n2.Ver Perfil\n3.Amigos\n4.Mensagens\n5.Comunidades\n6.Remover conta\n7.Sair");
            option = CheckException("Escolha uma das opções acima: ");
            input.nextLine();
        }
        
    }
    
    public void CreateCommunity(Sys system, User user)
    {
        System.out.print("Nome da comunidade: ");
        String name = input.nextLine();
        System.out.print("Descrição da comunidade: ");;
        String description = input.nextLine();
        Community community = new Community();
        community.setDescription(description);
        community.setName(name);
        community.adm = user;
        system.communities.add(community);   
    }
    
    public void SeeMessage(Sys system, User user)
    {
        System.out.println("Informe o login da pessoa que você quer ver a conversa.");
        System.out.print("Login: ");
        String login = input.nextLine();
        User friend = system.SearchUser(login);
        if(friend!=null)
        {
            if(user.CheckMessage(friend)!=null)
            {
                Message chat = user.CheckMessage(friend);
                chat.ShowMessages();
            }
        }
        else
        {
            System.out.println("Usuário não encontrado.");
        }
    }
    
    public void SendMessages(Sys system, User user)
    {
        System.out.println("Você pode enviar mensagem para qualquer pessoa do iFace, basta informar o login.");
        System.out.print("Login: ");
        String login = input.nextLine();
        Message chat = new Message();
        User friend = system.SearchUser(login);
        if(friend!=null)
        {
            System.out.println("Por favor, verifique a identidade do usuário.");
            System.out.println(friend.toString());
            System.out.print("Deseja enviar mensagem para o usuário: ");
            String option = input.nextLine();
            if(option.equals("sim"))
            {
               if(user.CheckMessage(friend)!=null)
               {
                   chat = user.CheckMessage(friend);
                   System.out.println("Para sair do envio de mensagens digite sair.");
                   chat.ShowMessages();
                   System.out.print("Mensagem: ");
                   String message = input.nextLine();
                   while(!message.equals("sair"))
                   {
                        chat.AddWhoSent(user.getLogin());
                        chat.AddMessage(message);
                        chat.ShowMessages();
                        System.out.println("Para sair do envio de mensagens digite sair.");
                        System.out.print("Mensagem: ");
                        message = input.nextLine();
                        
                    }
               }
               else
               {
                    System.out.println("Para sair do envio de mensagens digite sair.");
                    chat.ShowMessages();
                    System.out.print("Mensagem: ");
                    String message = input.nextLine();
                    while(!message.equals("sair"))
                    {
                        chat.AddWhoSent(user.getLogin());
                        chat.AddMessage(message);
                        chat.ShowMessages();
                        System.out.println("Para sair do envio de mensagens digite sair.");
                        System.out.print("Mensagem: ");
                        message = input.nextLine();
                        
                    }
                    chat.firstMember = user.getLogin();
                    chat.secondMember = friend.getLogin();
                    user.messages.add(chat);
                    friend.messages.add(chat);
               }
            }
            
        }
        else
        {
            System.out.println("Usuário não encontrado.");
        }
       
    }
    
    
    public int CheckException(String message){
        int number=0;
        boolean entry= false;
         while(!entry)
         {
            try{
                System.out.print(message);  
                number = Integer.parseInt(input.next());
                entry = true;
                }
                catch(NumberFormatException e){
                    System.out.println("A entrada esperada é um valor numérico.");
                }
        }
         return number;
    }
    
    public void CreatePerfil(User user)
    {
        System.out.print("Nome: ");
        String name = input.nextLine();
        System.out.print("E-mail: ");
        String email = input.nextLine();
        user.setEmail(email);
        user.setName(name);
        user.setPerfil("created");
    }
    
    public void AddFriend(Sys system, User user)
    {
        System.out.print("Login: ");
        String login = input.nextLine();
        User friend = system.SearchUser(login);
        if(friend!=null)
        {
            System.out.println("Por favor, verifique a identidade do usuário.");
            System.out.println(friend.toString());
            System.out.print("Deseja enviar convite ao usuário: ");
            String option = input.nextLine();
            if(option.equals("sim"))
            {
                friend.pendentsFriends.add(user);
            }
            else
            {
                System.out.println("Convite não será enviado.");
            }
        }
        else
        {
            System.out.println("Usuário não encontrado.");
        }
    }
    
    public void CheckInvites(User user)
    {
        user.Invites(user);
    }
   

}
