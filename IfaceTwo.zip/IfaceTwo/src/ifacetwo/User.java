/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ifacetwo;
import java.util.Scanner;
/**
 *
 * @author paulc
 */
public class User {
    protected String name;
    protected String email;
    protected String login;
    protected String password;
    protected String perfil = "not created";
    protected String Security;
    java.util.ArrayList<User> friends = new java.util.ArrayList<>();
    java.util.ArrayList<User> pendentsFriends = new java.util.ArrayList<>();
    java.util.ArrayList<Message> messages = new java.util.ArrayList<>();
    Scanner input = new Scanner(System.in);

    
    
    public void DeleteFriendsFromFriendList(User user)
    {
        int i;
        User friend;
        for(i=0;i<friends.size();i++)
        {
            friend = friends.get(i);
            if(friend.getLogin().equals(user.getLogin()))
            {
                friends.remove(friend);
            }
        } 
    }
    
    public void DeleteFriendsFromRequest(User user)
    {
        int i;
        User friend;
        for(i=0;i<pendentsFriends.size();i++)
        {
            friend = pendentsFriends.get(i);
            if(friend.getLogin().equals(user.getLogin()))
            {
                friends.remove(friend);
            }
        } 
    }
    
    public void DeleteMessages(User user){
        int i;
        Message msg;
        for(i=0;i<messages.size();i++)
        {
            msg = messages.get(i);
            if(msg.firstMember.equals(user.getLogin()) || msg.secondMember.equals(user.getLogin()))
            {
                messages.remove(msg);
            }
        }
    }

    public Message CheckMessage(User user)
    {
        int i;
        Message msg= null;
        for(i=0;i<messages.size();i++)
        {
            msg = messages.get(i);
            if(msg.firstMember.equals(user.getLogin()) || msg.firstMember.equals(user.getLogin()))
            {
                break;
            }
        }
        return msg;
        
    }
    
    public void Invites(User user){
        int i;
        User friend = new User();
        for(i=0;i<pendentsFriends.size();i++)
        {
            friend = pendentsFriends.get(i);
            System.out.println("Pedido de amizade enviado por "+friend.getLogin());
            System.out.println("Informações do usuário: ");
            System.out.println(friend.toString());
            System.out.print("Deseja aceitar: ");
            String option = input.nextLine();
            if(option.equals("sim"))
            {
                friends.add(friend);
                friend.friends.add(user);
                pendentsFriends.remove(friend);
                System.out.println("Agora você e "+friend.getName()+" são amigos.");
            }  
        }
    }
    
    public void FriendList()
    {
        int i;
        User friend = new User();
        for(i=0;i<friends.size();i++)
        {
            friend = friends.get(i);
            System.out.println(friend.toString());
        }
    }

    public String getSecurity() {
        return Security;
    }

    public void setSecurity(String Security) {
        this.Security = Security;
    }
    
    
    
    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String toString(){
        return "Nome: "+name+"\nE-mail: "+email;
    }
}
