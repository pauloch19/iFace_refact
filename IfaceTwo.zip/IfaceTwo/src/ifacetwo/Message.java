/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ifacetwo;

/**
 *
 * @author paulc
 */
public class Message {
    java.util.ArrayList<String> whoSent = new java.util.ArrayList<>();
    java.util.ArrayList<String> message = new java.util.ArrayList<>();
    String firstMember;
    String secondMember;
    
    
    public void DeleteMessageCMT(User user){
        int i;
        String person;
        for(i=0;i<whoSent.size();i++)
        {
            person = whoSent.get(i);
            if(person.equals(user.getLogin()))
            {
                whoSent.remove(person);
                message.remove(i);
            }
        }

    }
     
    
    public void AddWhoSent(String person){
        whoSent.add(person);
    }
    public void AddMessage(String msg){
        message.add(msg);
    }
    public void ShowMessages()
    {
        int i;
        for(i=0;i<message.size();i++)
        {
            System.out.println(whoSent.get(i)+": "+message.get(i));
        }
        
        
    }
    
 }
