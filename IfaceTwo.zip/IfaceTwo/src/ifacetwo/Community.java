/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ifacetwo;

import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author paulc
 */
public class Community {
    java.util.ArrayList<User> members = new java.util.ArrayList<>();
    Message message = new Message();
    java.util.ArrayList<User> requests = new java.util.ArrayList<>();
    User adm = new User();
    String description;
    String name;
    Scanner input = new Scanner(System.in);
    
    public String toString()
    {
        return "Nome da comunidade: "+name+"\nDescrição: "+description+"\nAdministrador: "+adm.getLogin();
    }
    
    public boolean SearchMember(User user)
    {
        int i;
        User usr = null;
        User member = new User();
        for(i=0;i<members.size();i++)
        {
            member = members.get(i);
            if(member.getLogin().equals(user.getLogin()))
            {
                return true;
            }
        
        } 
        return false;
    }
    
    public void SeeMembers()
    {
        int i;
        User user;
        System.out.println("Membros: ");
        for(i=0;i<members.size();i++)
        {
            user = members.get(i);
            System.out.println(user.getName());
        }
        
    }
    
    
    public void RemoveMember()
     {
        int i;
        User user;
        System.out.print("Login do usuário que você deseja remover: ");
        String login = input.nextLine();
        for(i=0;i<members.size();i++)
        {
            user = members.get(i);
            if(user.getLogin().equals(login))
            {
                System.out.print("Deseja remover o usuário "+user.getName()+" de login "+user.getLogin()+": ");
                String option = input.nextLine();
                if(option.equals("sim"))
                {
                    members.remove(user);
                    System.out.println("Usuário removido!");
                    break;
                }
                else
                {
                    System.out.println("Usuário não foi removido.");
                    break;
                }
            }
            
        }
         
     }
    
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
}
