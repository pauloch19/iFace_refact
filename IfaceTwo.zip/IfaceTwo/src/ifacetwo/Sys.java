/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ifacetwo;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author paulc
 */
public class Sys {
     Map< String, User> listUsers = new HashMap<String, User>();
     java.util.ArrayList<Community> communities = new java.util.ArrayList<>();
     Scanner input = new Scanner(System.in);
     
     public void Delete(User friend)
     {
        Set<String> keys = listUsers.keySet();
        for(String key: keys)
        {
            if(key!=null)
            {
                User user = listUsers.get(key);
                user.DeleteFriendsFromFriendList(friend);
                user.DeleteFriendsFromRequest(friend);
                user.DeleteMessages(friend);
            }
        }
     }
     
     public void DeleteFromCommunity(User user){
       int i;
       Community cmt;
       for(i=0;i<communities.size();i++)
       {
           cmt = communities.get(i);
           if(cmt.adm.getLogin().equals(user.getLogin()))
           {
               communities.remove(cmt);
           }
           else
           {
               if(cmt.SearchMember(user))
               {
                   cmt.message.DeleteMessageCMT(user); 
                   cmt.members.remove(user);               
               }
           }
       }   
     }
          
     public void SearchCommunity(User user)
     {
         int i;
         Community cmt = new Community();
         for(i=0;i<communities.size();i++)
         {
             cmt = communities.get(i);
             if(cmt.adm.getLogin().equals(user.getLogin()))
             {
                System.out.println("Lista de solicitações da comunidade "+cmt.getName()+": ");
                Requests(cmt);
             }
         }         
     }
     
     
     public void CommunitiesSystem(User user)
     {
         int i;
         Community cmt = new Community();
         for(i=0;i<communities.size();i++)
         {
             cmt = communities.get(i);
             System.out.println(cmt.toString());
             System.out.print("Deseja participar da comunidade acima: ");
             String option = input.nextLine();
             if(option.equals("sim"))
             {
                 if(!cmt.adm.getLogin().equals(user.getLogin()))
                 {
                     cmt.requests.add(user);
                     System.out.print("Você foi adicionado a lista de solicitações da comunidade");
                     System.out.println(", aguarde o administrador aceitar.");
                 }
                 else
                 {
                     System.out.println("Você não pode participar dessa comunidade pois é o administrador.");
                 }
             }
         }         
     }
     
     public void SeeMyCommunities(User user)
     {
         int i;
         Community cmt;
         for(i=0;i<communities.size();i++)
         {
             cmt = communities.get(i);
             if(cmt.adm.getLogin().equals(user.getLogin()))
             {
                System.out.print("Deseja ver as informações dessa comunidade "+cmt.getName()+": ");
                String option = input.nextLine();
                if(option.equals("sim"))
                {
                    System.out.println(cmt.toString());
                    cmt.SeeMembers();
                    if(cmt.message!=null)
                    {
                        System.out.println("Mensagens: ");
                        cmt.message.ShowMessages();
                    }
                    
                }
             }
             else
             {
                 if(cmt.SearchMember(user))
                 {
                    System.out.print("Deseja ver as informações dessa comunidade "+cmt.getName()+": ");
                    String option = input.nextLine();
                    if(option.equals("sim"))
                    {
                        System.out.println(cmt.toString());
                        cmt.SeeMembers();
                        if(cmt.message!=null)
                        {
                            System.out.println("Mensagens: ");
                            cmt.message.ShowMessages();
                        }
                    }
                 }
             }
             
         }
     }
     
     public void RemoveMember(User user, String name)
     {
         int i;
         Community cmt = new Community();
         for(i=0;i<communities.size();i++)
         {
             cmt = communities.get(i);
             if(cmt.getName().equals(name))
             {
                 if(cmt.adm.getLogin().equals(user.getLogin()))
                {
                    cmt.RemoveMember();
                    break;
                }
             }
             
         }         
     }
     
     public void Requests(Community cmt)
     {
         int i;
         User user;
         for(i=0;i<cmt.requests.size();i++)
         {
             user = cmt.requests.get(i);
             System.out.println(user.toString());
             System.out.print("Deseja aceitar o usuário acima: ");
             String option = input.nextLine();
             if(option.equals("sim"))
             {
                 cmt.members.add(user);
                 cmt.requests.remove(user);
                 System.out.println("Agora o usuário "+user.getLogin()+" é membro da comunidade");
             }
             if(option.equals("nao"))
             {
                 cmt.requests.remove(user);
                 System.out.println("O usuário´não será membro da comunidade");
             }
         }
         
     }
     
     
     public void CommunityMessage(String name, User user){
         int i;
         Community cmt;
         for(i=0;i<communities.size();i++)
         {
             cmt= communities.get(i);
             if(cmt.getName().equals(name))
             {
                 System.out.print("Deseja enviar mensagem para essa comunidade: ");
                 String option = input.nextLine();
                 if(option.equals("sim"))
                 {
                     SendMessage(cmt, user);
                     break;
                 }
                 else
                 {
                     System.out.println("Não será enviada nenhuma mensagem.");
                     break;
                 }
             }
         }
           
     }
     
     public void SendMessage(Community cmt, User user)
     {
        
         System.out.println("Para parar de mandar mensagem, digite sair.");
         if(cmt.message!=null)
         {
            cmt.message.ShowMessages();
         }
         System.out.print("Mensagem: ");
         String msg = input.nextLine();
         while(!msg.equals("sair"))
         {
            cmt.message.whoSent.add(user.getLogin());
            cmt.message.message.add(msg);
            if(cmt.message!=null)
            {
                cmt.message.ShowMessages();
            }
            System.out.println("Para parar de mandar mensagem, digite sair.");
            System.out.print("Mensagem: ");
            msg = input.nextLine();  
         } 
     }
     
     public boolean SearchForEqualsLogin(String login){
       return listUsers.containsValue(login);
      
     }
     
     public void AddUser(User user)
     {
         listUsers.put(user.getLogin(), user);
     }
     
     public User SearchUser(String login)
     {
        User user = listUsers.get(login);
        return user;
     }
     
     
     
}
